﻿param(
    [int]$DurationSeconds = 0,
    [int]$IntervalSeconds = 1,
    [string[]]$ProcessPatterns = @('Blitz', 'Blitz.exe', 'Blitz Helper', 'BlitzApp'),
    [string]$TraceSlug = "blitz",
    [string]$AppDisplayName = "Blitz",
    [string]$OutputDir = "",
    [string]$TcpViewImportPath = "",
    [string]$ExternalListsDir = "",
    [string[]]$AllowedDomainSuffixes = @(),
    [switch]$DisableExternalListSync
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-BlitzFixRoot {
    $scriptRoot = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($scriptRoot)) {
        if (-not [string]::IsNullOrWhiteSpace($PSCommandPath)) {
            $scriptRoot = Split-Path -Parent $PSCommandPath
        } else {
            $scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
        }
    }

    return (Resolve-Path (Join-Path $scriptRoot "..")).Path
}

function Resolve-CanonicalPath {
    param(
        [string]$Root,
        [string]$Candidate,
        [string]$DefaultChild
    )

    $path = ""
    if ([string]::IsNullOrWhiteSpace($Candidate)) {
        $path = Join-Path $Root $DefaultChild
    } elseif ([System.IO.Path]::IsPathRooted($Candidate)) {
        $path = $Candidate
    } else {
        $path = Join-Path $Root $Candidate
    }

    if (Test-Path -LiteralPath $path) {
        return (Resolve-Path -LiteralPath $path).Path
    }

    return [System.IO.Path]::GetFullPath($path)
}

function Ensure-Directory {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        [void](New-Item -ItemType Directory -Path $Path -Force)
    }
}

function Get-RelativeBlitzFixPath {
    param(
        [string]$Path,
        [string]$Root
    )

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return ""
    }

    if ($Path.StartsWith($Root, [System.StringComparison]::OrdinalIgnoreCase)) {
        return $Path.Substring($Root.Length).TrimStart('\', '/')
    }

    return $Path
}

function Get-Stamp {
    param([datetime]$Value = (Get-Date))

    return $Value.ToString("yyyyMMdd-HHmmss")
}

$script:liveLogPath = ""

function Write-LiveMessage {
    param(
        [string]$Message,
        [string]$ForegroundColor = "Gray"
    )

    Write-Host $Message -ForegroundColor $ForegroundColor
    if (-not [string]::IsNullOrWhiteSpace($script:liveLogPath)) {
        try {
            $Message | Out-File -FilePath $script:liveLogPath -Append -Encoding UTF8 -ErrorAction SilentlyContinue
        } catch {}
    }
}

function Write-Info {
    param([string]$Message)

    Write-LiveMessage -Message $Message -ForegroundColor Gray
}

function Write-WarnLine {
    param(
        [string]$Message,
        [System.Collections.Generic.List[string]]$Warnings
    )

    Write-LiveMessage -Message $Message -ForegroundColor Yellow
    [void]$Warnings.Add($Message)
}


function Test-NameMatches {
    param(
        [string]$Text,
        [string[]]$Patterns
    )

    $haystack = ([string]$Text).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($haystack)) {
        return $false
    }

    $haystackNoExe = $haystack -replace '\.exe$', ''
    foreach ($pattern in @($Patterns)) {
        $needle = ([string]$pattern).Trim().ToLowerInvariant()
        if ([string]::IsNullOrWhiteSpace($needle)) {
            continue
        }

        $needleNoExe = $needle -replace '\.exe$', ''
        if ($haystack -eq $needle -or $haystackNoExe -eq $needleNoExe -or $haystack.Contains($needle) -or $haystackNoExe.Contains($needleNoExe)) {
            return $true
        }
    }

    return $false
}

function Get-ProcessNameText {
    param([object]$Process)

    if ($Process.PSObject.Properties.Match('ProcessName').Count -gt 0) {
        return [string]$Process.ProcessName
    }

    if ($Process.PSObject.Properties.Match('Name').Count -gt 0) {
        return [string]$Process.Name
    }

    return ""
}

function Get-ProcessPathText {
    param([object]$Process)

    if ($Process.PSObject.Properties.Match('Path').Count -gt 0) {
        $path = [string]$Process.Path
        if (-not [string]::IsNullOrWhiteSpace($path)) {
            return $path
        }
    }

    if ($Process.PSObject.Properties.Match('MainModule').Count -gt 0) {
        try {
            $mainModulePath = [string]$Process.MainModule.FileName
            if (-not [string]::IsNullOrWhiteSpace($mainModulePath)) {
                return $mainModulePath
            }
        } catch {
        }
    }

    if ($Process.PSObject.Properties.Match('ExecutablePath').Count -gt 0) {
        return [string]$Process.ExecutablePath
    }

    return ""
}

function Get-ProcessStartTimeText {
    param([object]$Process)

    try {
        return ([datetimeoffset]$Process.StartTime).ToString("o")
    } catch {
        return ""
    }
}

function Test-ProcessMatches {
    param(
        [object]$Process,
        [string[]]$Patterns
    )

    $name = Get-ProcessNameText -Process $Process
    if (Test-NameMatches -Text $name -Patterns $Patterns) {
        return $true
    }

    $path = Get-ProcessPathText -Process $Process
    if ([string]::IsNullOrWhiteSpace($path)) {
        return $false
    }

    foreach ($segment in @($path -split '[\\/]' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })) {
        if (Test-NameMatches -Text $segment -Patterns $Patterns) {
            return $true
        }
    }

    return $false
}

function Get-ProcessSnapshot {
    param(
        [string[]]$Patterns,
        [System.Collections.Generic.List[string]]$Warnings
    )

    $rows = New-Object System.Collections.Generic.List[object]
    $byPid = @{}

    try {
        $matches = @(Get-Process -ErrorAction Stop | Where-Object {
            $_.Id -gt 0 -and (Test-ProcessMatches -Process $_ -Patterns $Patterns)
        })
    } catch {
        Write-WarnLine -Message ("Get-Process failed: {0}" -f $_.Exception.Message) -Warnings $Warnings
        $matches = @()
    }

    foreach ($process in $matches) {
        $row = [PSCustomObject]@{
            pid = [int]$process.Id
            processName = Get-ProcessNameText -Process $process
            processPath = Get-ProcessPathText -Process $process
            startTime = Get-ProcessStartTimeText -Process $process
        }

        [void]$rows.Add($row)
        $byPid[[string]$row.pid] = $row
    }

    return [PSCustomObject]@{
        processes = @($rows.ToArray())
        byPid = $byPid
    }
}

function Try-ParseIntValue {
    param([string]$Text)

    $value = ([string]$Text).Trim()
    if ([string]::IsNullOrWhiteSpace($value)) {
        return $null
    }

    $value = $value -replace '[,\s]', ''
    $parsed = 0
    if ([int]::TryParse($value, [ref]$parsed)) {
        return $parsed
    }

    return $null
}

function Get-IntOrZero {
    param([object]$Value)

    if ($null -eq $Value) {
        return 0
    }

    return [int]$Value
}

function ConvertTo-IsoTimestamp {
    param([string]$Text)

    $value = ([string]$Text).Trim()
    if ([string]::IsNullOrWhiteSpace($value)) {
        return ""
    }

    $dateTimeOffset = [datetimeoffset]::MinValue
    if ([datetimeoffset]::TryParse($value, [ref]$dateTimeOffset)) {
        return $dateTimeOffset.ToString("o")
    }

    $dateTime = [datetime]::MinValue
    if ([datetime]::TryParse($value, [ref]$dateTime)) {
        return ([datetimeoffset]$dateTime).ToString("o")
    }

    return ""
}

function Test-IsIpAddress {
    param([string]$Text)

    $ip = $null
    return -not [string]::IsNullOrWhiteSpace($Text) -and [System.Net.IPAddress]::TryParse($Text.Trim(), [ref]$ip)
}

function Normalize-IpAddress {
    param([string]$Text)

    $ip = $null
    if ([string]::IsNullOrWhiteSpace($Text) -or -not [System.Net.IPAddress]::TryParse($Text.Trim(), [ref]$ip)) {
        return ""
    }

    return $ip.ToString().ToLowerInvariant()
}

function Normalize-HostValue {
    param([string]$Text)

    $value = ([string]$Text).Trim().Trim('"').Trim()
    if ([string]::IsNullOrWhiteSpace($value)) {
        return ""
    }

    if ($value -eq '*') {
        return '*'
    }

    if ($value.StartsWith('[') -and $value.EndsWith(']')) {
        $value = $value.TrimStart('[').TrimEnd(']')
    }

    $ipValue = Normalize-IpAddress -Text $value
    if (-not [string]::IsNullOrWhiteSpace($ipValue)) {
        return $ipValue
    }

    return $value.TrimEnd('.').ToLowerInvariant()
}

function Get-RemoteKind {
    param([string]$Value)

    if (Test-IsIpAddress -Text $Value) {
        return "ip"
    }

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return "unknown"
    }

    $trimmed = $Value.Trim()
    if ($trimmed -eq '*' -or $trimmed -eq '0.0.0.0' -or $trimmed -eq '::') {
        return "unknown"
    }

    if ($trimmed -match '[A-Za-z]') {
        return "domain"
    }

    return "unknown"
}

function Normalize-Protocol {
    param([string]$Text)

    $value = ([string]$Text).Trim().ToUpperInvariant()
    if ([string]::IsNullOrWhiteSpace($value)) {
        return "TCP"
    }

    return $value
}

function Normalize-State {
    param([string]$Text)

    $value = ([string]$Text).Trim()
    if ([string]::IsNullOrWhiteSpace($value)) {
        return ""
    }

    $token = $value.ToLowerInvariant() -replace '[^a-z0-9]+', ''
    switch ($token) {
        'synsent' { return 'Syn Sent' }
        'established' { return 'Established' }
        'listening' { return 'Listening' }
        'listen' { return 'Listening' }
        'closewait' { return 'Close Wait' }
        'timewait' { return 'Time Wait' }
        default {
            $textInfo = [System.Globalization.CultureInfo]::InvariantCulture.TextInfo
            return $textInfo.ToTitleCase($value.ToLowerInvariant())
        }
    }
}

function Split-EndpointHostPort {
    param([string]$Text)

    $value = ([string]$Text).Trim().Trim('"').Trim()
    if ([string]::IsNullOrWhiteSpace($value)) {
        return [PSCustomObject]@{
            address = ""
            port = $null
        }
    }

    if ($value -match '^\[(?<address>[^\]]+)\]:(?<port>\d+)$') {
        return [PSCustomObject]@{
            address = Normalize-HostValue -Text $Matches.address
            port = Try-ParseIntValue -Text $Matches.port
        }
    }

    $lastColonIndex = $value.LastIndexOf(':')
    if ($lastColonIndex -gt 0 -and $lastColonIndex -lt ($value.Length - 1)) {
        $portText = $value.Substring($lastColonIndex + 1)
        $addressText = $value.Substring(0, $lastColonIndex)
        $parsedPort = Try-ParseIntValue -Text $portText
        if ($null -ne $parsedPort) {
            return [PSCustomObject]@{
                address = Normalize-HostValue -Text $addressText
                port = $parsedPort
            }
        }
    }

    return [PSCustomObject]@{
        address = Normalize-HostValue -Text $value
        port = $null
    }
}

function Add-SetValue {
    param(
        [hashtable]$Set,
        [string]$Value
    )

    $text = ([string]$Value).Trim()
    if ([string]::IsNullOrWhiteSpace($text)) {
        return
    }

    $Set[$text] = $true
}

function New-LineSetFromFile {
    param([string]$Path)

    $set = @{}
    if (Test-Path -LiteralPath $Path) {
        foreach ($line in @(Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)) {
            $value = ([string]$line).Trim()
            if (-not [string]::IsNullOrWhiteSpace($value)) {
                $set[$value] = $true
            }
        }
    }

    return $set
}

function Test-ExternalIpCandidate {
    param([string]$Value)

    $ip = $null
    if ([string]::IsNullOrWhiteSpace($Value) -or -not [System.Net.IPAddress]::TryParse($Value.Trim(), [ref]$ip)) {
        return $false
    }

    if ($ip.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) {
        return $false
    }

    $bytes = $ip.GetAddressBytes()
    if ($bytes[0] -eq 0 -or $bytes[0] -eq 10 -or $bytes[0] -eq 127 -or $bytes[0] -ge 224) {
        return $false
    }
    if ($bytes[0] -eq 169 -and $bytes[1] -eq 254) {
        return $false
    }
    if ($bytes[0] -eq 172 -and $bytes[1] -ge 16 -and $bytes[1] -le 31) {
        return $false
    }
    if ($bytes[0] -eq 192 -and $bytes[1] -eq 168) {
        return $false
    }

    return $true
}

function Test-ExternalDomainCandidate {
    param([string]$Value)

    $domain = ([string]$Value).Trim().Trim('.').ToLowerInvariant()
    if ((Get-RemoteKind -Value $domain) -ne 'domain') {
        return $false
    }
    if ($domain -eq 'localhost' -or $domain.EndsWith('.in-addr.arpa') -or $domain.EndsWith('.ip6.arpa')) {
        return $false
    }

    return $true
}

function Test-AllowedDomainCandidate {
    param([string]$Value)

    if (-not (Test-ExternalDomainCandidate -Value $Value)) {
        return $false
    }
    if (@($AllowedDomainSuffixes).Count -eq 0) {
        return $true
    }

    $domain = ([string]$Value).Trim().Trim('.').ToLowerInvariant()
    foreach ($suffixValue in @($AllowedDomainSuffixes)) {
        $suffix = ([string]$suffixValue).Trim().Trim('.').ToLowerInvariant()
        if ($suffix -and ($domain -eq $suffix -or $domain.EndsWith(".$suffix"))) {
            return $true
        }
    }
    return $false
}

function Test-ExternalEndpointRecord {
    param([object]$Record)

    $remoteAddress = [string]$Record.remoteAddress
    return (Test-ExternalIpCandidate -Value $remoteAddress) -or
        (Test-AllowedDomainCandidate -Value $remoteAddress)
}

function Add-NewLinesToExternalFile {
    param(
        [string]$Path,
        [hashtable]$KnownSet,
        [string[]]$Values
    )

    $newValues = New-Object System.Collections.Generic.List[string]
    foreach ($value in @($Values)) {
        $line = ([string]$value).Trim()
        if ([string]::IsNullOrWhiteSpace($line) -or $KnownSet.ContainsKey($line)) {
            continue
        }

        $KnownSet[$line] = $true
        [void]$newValues.Add($line)
    }

    if ($newValues.Count -gt 0) {
        Add-Content -LiteralPath $Path -Value @($newValues.ToArray()) -Encoding UTF8
    }

    return $newValues.Count
}

function Sync-ExternalLists {
    param(
        [object]$State,
        [hashtable]$IpSet,
        [hashtable]$DomainSet
    )

    if ($null -eq $State -or -not $State.Enabled) {
        return [PSCustomObject]@{ ips = 0; domains = 0 }
    }

    $ips = @($IpSet.Keys | Where-Object { Test-ExternalIpCandidate -Value $_ } | Sort-Object -Unique)
    $domains = @($DomainSet.Keys | Where-Object { Test-ExternalDomainCandidate -Value $_ } | Sort-Object -Unique)

    $addedIps = Add-NewLinesToExternalFile -Path $State.IpPath -KnownSet $State.Ips -Values $ips
    $addedDomains = Add-NewLinesToExternalFile -Path $State.DomainPath -KnownSet $State.Domains -Values $domains

    return [PSCustomObject]@{
        ips = $addedIps
        domains = $addedDomains
    }
}

function New-ExternalCandidateSets {
    param([object[]]$Endpoints)

    $ips = @{}
    $domains = @{}

    foreach ($endpoint in @($Endpoints)) {
        $remoteAddress = [string]$endpoint.remoteAddress
        $remoteKind = Get-RemoteKind -Value $remoteAddress

        if ($remoteKind -eq 'ip') {
            if (Test-ExternalIpCandidate -Value $remoteAddress) {
                Add-SetValue -Set $ips -Value $remoteAddress
            }
            continue
        }

        if ($remoteKind -eq 'domain') {
            if (Test-ExternalDomainCandidate -Value $remoteAddress) {
                Add-SetValue -Set $domains -Value $remoteAddress
            }
            foreach ($domain in @($endpoint.domainCandidates)) {
                if (Test-ExternalDomainCandidate -Value $domain) {
                    Add-SetValue -Set $domains -Value $domain
                }
            }
        }
    }

    return [PSCustomObject]@{
        Ips = $ips
        Domains = $domains
    }
}

function Add-CountValue {
    param(
        [hashtable]$Counts,
        [string]$Key,
        [int]$Amount = 1
    )

    $text = ([string]$Key).Trim()
    if ([string]::IsNullOrWhiteSpace($text)) {
        return
    }

    if ($Counts.ContainsKey($text)) {
        $Counts[$text] += $Amount
    } else {
        $Counts[$text] = $Amount
    }
}

function Add-MapSetValue {
    param(
        [hashtable]$Map,
        [string]$Key,
        [string]$Value
    )

    $mapKey = ([string]$Key).Trim()
    $mapValue = ([string]$Value).Trim()
    if ([string]::IsNullOrWhiteSpace($mapKey) -or [string]::IsNullOrWhiteSpace($mapValue)) {
        return
    }

    if (-not $Map.ContainsKey($mapKey)) {
        $Map[$mapKey] = @{}
    }

    $Map[$mapKey][$mapValue] = $true
}

function Get-DnsCacheSnapshot {
    param(
        [string]$Timestamp,
        [System.Collections.Generic.List[string]]$Warnings
    )

    $rows = New-Object System.Collections.Generic.List[object]

    try {
        foreach ($record in @(Get-DnsClientCache -ErrorAction Stop)) {
            [void]$rows.Add([PSCustomObject]@{
                timestamp = $Timestamp
                entry = ([string]$record.Entry).Trim().ToLowerInvariant()
                name = ([string]$record.Name).Trim().ToLowerInvariant()
                data = Normalize-HostValue -Text ([string]$record.Data)
                type = [string]$record.Type
            })
        }
    } catch {
        Write-WarnLine -Message ("Get-DnsClientCache failed: {0}" -f $_.Exception.Message) -Warnings $Warnings
    }

    return @($rows.ToArray())
}

function New-DnsIndex {
    param([object[]]$Records)

    $byIp = @{}
    $byDomain = @{}
    $cnames = @{}

    # First pass: collect CNAME / domain-to-domain alias mappings
    foreach ($record in @($Records)) {
        $dataVal = Normalize-HostValue -Text ([string]$record.data)
        if ([string]::IsNullOrWhiteSpace($dataVal)) {
            continue
        }

        # If data is a domain, treat it as a CNAME/alias target
        if ((Get-RemoteKind -Value $dataVal) -eq 'domain') {
            foreach ($candidate in @([string]$record.entry, [string]$record.name)) {
                $alias = Normalize-HostValue -Text $candidate
                if ((Get-RemoteKind -Value $alias) -eq 'domain' -and $alias -ne $dataVal) {
                    if (-not $cnames.ContainsKey($dataVal)) {
                        $cnames[$dataVal] = @{}
                    }
                    $cnames[$dataVal][$alias] = $true
                }
            }
        }
    }

    # Helper function for transitive CNAME resolution
    $resolveAliases = {
        param([string]$domain)
        $visited = @{}
        $queue = New-Object System.Collections.Generic.Queue[string]
        $queue.Enqueue($domain)
        $visited[$domain] = $true
        
        $all = New-Object System.Collections.Generic.List[string]
        while ($queue.Count -gt 0) {
            $current = $queue.Dequeue()
            [void]$all.Add($current)
            if ($cnames.ContainsKey($current)) {
                foreach ($alias in $cnames[$current].Keys) {
                    if (-not $visited.ContainsKey($alias)) {
                        $visited[$alias] = $true
                        $queue.Enqueue($alias)
                    }
                }
            }
        }
        return @($all.ToArray())
    }

    # Second pass: map IPs to all transitive domains
    foreach ($record in @($Records)) {
        $ipValue = Normalize-IpAddress -Text ([string]$record.data)
        if ([string]::IsNullOrWhiteSpace($ipValue)) {
            continue
        }

        foreach ($candidate in @([string]$record.entry, [string]$record.name)) {
            $domain = Normalize-HostValue -Text $candidate
            if ((Get-RemoteKind -Value $domain) -ne 'domain') {
                continue
            }

            # Get all aliases for this domain
            $resolvedDomains = &$resolveAliases $domain
            foreach ($d in $resolvedDomains) {
                Add-MapSetValue -Map $byIp -Key $ipValue -Value $d
                Add-MapSetValue -Map $byDomain -Key $d -Value $ipValue
            }
        }
    }

    return [PSCustomObject]@{
        byIp = $byIp
        byDomain = $byDomain
    }
}

function Get-DnsNamesForIp {
    param(
        [string]$IpAddress,
        [hashtable]$DnsByIp
    )

    $ipValue = Normalize-IpAddress -Text $IpAddress
    if ([string]::IsNullOrWhiteSpace($ipValue) -or -not $DnsByIp.ContainsKey($ipValue)) {
        return @()
    }

    return @($DnsByIp[$ipValue].Keys | Sort-Object)
}

function Test-AddressMatch {
    param(
        [string]$Left,
        [string]$Right,
        [hashtable]$DnsByIp,
        [hashtable]$DnsByDomain
    )

    $leftValue = Normalize-HostValue -Text $Left
    $rightValue = Normalize-HostValue -Text $Right
    if ([string]::IsNullOrWhiteSpace($leftValue) -or [string]::IsNullOrWhiteSpace($rightValue)) {
        return $false
    }

    if ($leftValue -eq $rightValue) {
        return $true
    }

    $leftKind = Get-RemoteKind -Value $leftValue
    $rightKind = Get-RemoteKind -Value $rightValue

    if ($leftKind -eq 'domain' -and $rightKind -eq 'ip' -and $DnsByDomain.ContainsKey($leftValue)) {
        return $DnsByDomain[$leftValue].ContainsKey($rightValue)
    }

    if ($rightKind -eq 'domain' -and $leftKind -eq 'ip' -and $DnsByDomain.ContainsKey($rightValue)) {
        return $DnsByDomain[$rightValue].ContainsKey($leftValue)
    }

    if ($leftKind -eq 'ip' -and $rightKind -eq 'domain' -and $DnsByIp.ContainsKey($leftValue)) {
        return $DnsByIp[$leftValue].ContainsKey($rightValue)
    }

    if ($rightKind -eq 'ip' -and $leftKind -eq 'domain' -and $DnsByIp.ContainsKey($rightValue)) {
        return $DnsByIp[$rightValue].ContainsKey($leftValue)
    }

    return $false
}

function New-RawRecord {
    param(
        [string]$Timestamp,
        [string]$Source,
        [string]$ProcessName,
        [int]$ProcessId,
        [string]$ProcessPath,
        [string]$Protocol,
        [string]$State,
        [string]$LocalAddress,
        [object]$LocalPort,
        [string]$RemoteAddress,
        [object]$RemotePort,
        [string[]]$DomainCandidates = @(),
        [string]$CreateTime = "",
        [string]$ModuleName = "",
        [object]$SentPackets = $null,
        [object]$RecvPackets = $null,
        [object]$SentBytes = $null,
        [object]$RecvBytes = $null
    )

    $candidateSet = @{}
    foreach ($candidate in @($DomainCandidates)) {
        $domain = Normalize-HostValue -Text $candidate
        if ((Get-RemoteKind -Value $domain) -eq 'domain') {
            $candidateSet[$domain] = $true
        }
    }

    return [PSCustomObject]@{
        timestamp = $Timestamp
        source = $Source
        processName = ([string]$ProcessName).Trim()
        pid = $ProcessId
        processPath = ([string]$ProcessPath).Trim()
        protocol = Normalize-Protocol -Text $Protocol
        state = Normalize-State -Text $State
        localAddress = Normalize-HostValue -Text $LocalAddress
        localPort = $LocalPort
        remoteAddress = Normalize-HostValue -Text $RemoteAddress
        remotePort = $RemotePort
        domainCandidates = @($candidateSet.Keys | Sort-Object)
        confidence = if ($candidateSet.Count -gt 0) { 'high' } else { 'none' }
        createTime = $CreateTime
        moduleName = $ModuleName
        sentPackets = $SentPackets
        recvPackets = $RecvPackets
        sentBytes = $SentBytes
        recvBytes = $RecvBytes
    }
}

function Get-LiveConnectionRecords {
    param(
        [string]$Timestamp,
        [hashtable]$ProcessByPid,
        [System.Collections.Generic.List[string]]$Warnings
    )

    $rows = New-Object System.Collections.Generic.List[object]

    try {
        $connections = @(Get-NetTCPConnection -ErrorAction Stop | Where-Object {
            $ProcessByPid.ContainsKey([string][int]$_.OwningProcess)
        })
    } catch {
        Write-WarnLine -Message ("Get-NetTCPConnection failed: {0}" -f $_.Exception.Message) -Warnings $Warnings
        $connections = @()
    }

    foreach ($connection in $connections) {
        $process = $ProcessByPid[[string][int]$connection.OwningProcess]
        [void]$rows.Add((New-RawRecord `
            -Timestamp $Timestamp `
            -Source 'live_trace' `
            -ProcessName $process.processName `
            -ProcessId $process.pid `
            -ProcessPath $process.processPath `
            -Protocol 'TCP' `
            -State ([string]$connection.State) `
            -LocalAddress ([string]$connection.LocalAddress) `
            -LocalPort ([int]$connection.LocalPort) `
            -RemoteAddress ([string]$connection.RemoteAddress) `
            -RemotePort ([int]$connection.RemotePort)))
    }

    try {
        $udpEndpoints = @(Get-NetUDPEndpoint -ErrorAction Stop | Where-Object {
            $ProcessByPid.ContainsKey([string][int]$_.OwningProcess)
        })
    } catch {
        Write-WarnLine -Message ("Get-NetUDPEndpoint failed: {0}" -f $_.Exception.Message) -Warnings $Warnings
        $udpEndpoints = @()
    }

    foreach ($endpoint in $udpEndpoints) {
        $process = $ProcessByPid[[string][int]$endpoint.OwningProcess]
        [void]$rows.Add((New-RawRecord `
            -Timestamp $Timestamp `
            -Source 'live_trace' `
            -ProcessName $process.processName `
            -ProcessId $process.pid `
            -ProcessPath $process.processPath `
            -Protocol 'UDP' `
            -State 'Bound' `
            -LocalAddress ([string]$endpoint.LocalAddress) `
            -LocalPort ([int]$endpoint.LocalPort) `
            -RemoteAddress '' `
            -RemotePort $null))
    }

    return @($rows.ToArray())
}

function Get-TcpvconSnapshotRecords {
    param(
        [string]$Timestamp,
        [string]$TcpvconPath,
        [object[]]$Processes,
        [string[]]$Patterns,
        [string[]]$TcpvconFlags,
        [System.Collections.Generic.List[string]]$Warnings
    )

    $rows = New-Object System.Collections.Generic.List[object]
    if ([string]::IsNullOrWhiteSpace($TcpvconPath) -or -not (Test-Path -LiteralPath $TcpvconPath)) {
        return [PSCustomObject]@{
            records = @()
            status = "skipped"
        }
    }

    $status = "ok"
    foreach ($process in @($Processes)) {
        $pidText = [string]$process.pid
        if ([string]::IsNullOrWhiteSpace($pidText)) {
            continue
        }

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $TcpvconPath
        
        $argsList = @()
        if ($null -ne $TcpvconFlags -and $TcpvconFlags.Count -gt 0) {
            $argsList += $TcpvconFlags
        } else {
            $argsList += @("-a", "-c", "-nobanner")
        }
        $argsList += $pidText
        $psi.Arguments = $argsList -join " "
        $psi.UseShellExecute = $false
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.CreateNoWindow = $true

        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi

        $started = $false
        try {
            $started = $proc.Start()
        } catch {
            $status = "failed"
            Write-WarnLine -Message ("Failed to start tcpvcon for PID {0}: {1}" -f $pidText, $_.Exception.Message) -Warnings $Warnings
            continue
        }

        $outputLines = @()
        if ($started) {
            if ($proc.WaitForExit(3000)) {
                $stdout = $proc.StandardOutput.ReadToEnd()
                $outputLines = $stdout -split "`r?`n"
            } else {
                try {
                    $proc.Kill()
                } catch {}
                $status = "timeout"
                Write-WarnLine -Message ("Warning: tcpvcon call for PID {0} timed out after 3 seconds." -f $pidText) -Warnings $Warnings
                continue
            }
        }

        foreach ($line in $outputLines) {
            $text = ([string]$line).Trim()
            if ([string]::IsNullOrWhiteSpace($text)) {
                continue
            }

            $row = $null
            try {
                $row = ConvertFrom-Csv -Header @('protocol', 'processName', 'pid', 'state', 'localAddress', 'remoteAddress') -InputObject $text
            } catch {
                $row = $null
            }

            if ($null -eq $row) {
                continue
            }

            if (-not (Test-NameMatches -Text ([string]$row.processName) -Patterns $Patterns)) {
                continue
            }

            $remoteValue = Normalize-HostValue -Text ([string]$row.remoteAddress)
            $localValue = Normalize-HostValue -Text ([string]$row.localAddress)
            $directCandidates = @()
            if ((Get-RemoteKind -Value $remoteValue) -eq 'domain') {
                $directCandidates = @($remoteValue)
            }

            [void]$rows.Add((New-RawRecord `
                -Timestamp $Timestamp `
                -Source 'tcpview_console' `
                -ProcessName ([string]$row.processName) `
                -ProcessId (Get-IntOrZero -Value (Try-ParseIntValue -Text ([string]$row.pid))) `
                -ProcessPath $process.processPath `
                -Protocol ([string]$row.protocol) `
                -State ([string]$row.state) `
                -LocalAddress $localValue `
                -LocalPort $null `
                -RemoteAddress $remoteValue `
                -RemotePort $null `
                -DomainCandidates $directCandidates))
        }
    }

    return [PSCustomObject]@{
        records = @($rows.ToArray())
        status = $status
    }
}

function Split-TcpViewImportLine {
    param(
        [string]$Line,
        [string]$Mode
    )

    switch ($Mode) {
        'tab' {
            return @($Line -split "`t", -1)
        }
        'csv' {
            return @($Line -split ',', -1)
        }
        default {
            return @([regex]::Split($Line.TrimEnd(), '\s{2,}'))
        }
    }
}

function Get-TcpViewImportHeader {
    param([string[]]$Lines)

    for ($index = 0; $index -lt $Lines.Count; $index++) {
        $line = $Lines[$index]
        if ([string]::IsNullOrWhiteSpace($line)) {
            continue
        }

        $mode = 'space'
        if ($line.Contains("`t")) {
            $mode = 'tab'
        } elseif ($line.Contains(",")) {
            $mode = 'csv'
        }

        $columns = @()
        if ($mode -eq 'csv') {
            $columns = @($line -split ',', -1)
        } else {
            $columns = Split-TcpViewImportLine -Line $line -Mode $mode
        }

        $normalizedColumns = @($columns | ForEach-Object { (($_ -replace '[^A-Za-z0-9]+', '')).ToLowerInvariant() })
        if (($normalizedColumns -contains 'process') -or ($normalizedColumns -contains 'processname')) {
            return [PSCustomObject]@{
                index = $index
                mode = $mode
                columns = $columns
                map = @{}
            }
        }
    }

    return $null
}

function Get-ImportValue {
    param(
        [string[]]$Columns,
        [hashtable]$Map,
        [string[]]$Aliases
    )

    foreach ($alias in @($Aliases)) {
        $key = ($alias -replace '[^A-Za-z0-9]+', '').ToLowerInvariant()
        if ($Map.ContainsKey($key)) {
            $position = [int]$Map[$key]
            if ($position -ge 0 -and $position -lt $Columns.Count) {
                return [string]$Columns[$position]
            }
        }
    }

    return ""
}

function Import-TcpViewFallbackRecords {
    param(
        [string]$Path,
        [string[]]$Patterns,
        [string]$ImportedAt,
        [System.Collections.Generic.List[string]]$Warnings
    )

    $rows = New-Object System.Collections.Generic.List[object]
    if (-not (Test-Path -LiteralPath $Path)) {
        return @()
    }

    $lines = @(Get-Content -LiteralPath $Path)
    if ($lines.Count -eq 0) {
        return @()
    }

    $headerInfo = Get-TcpViewImportHeader -Lines $lines
    if ($null -eq $headerInfo) {
        Write-WarnLine -Message ("TCPView import header not recognized: {0}" -f $Path) -Warnings $Warnings
        return @()
    }

    $headerMap = @{}
    for ($i = 0; $i -lt $headerInfo.columns.Count; $i++) {
        $headerMap[(($headerInfo.columns[$i] -replace '[^A-Za-z0-9]+', '')).ToLowerInvariant()] = $i
    }

    for ($lineIndex = $headerInfo.index + 1; $lineIndex -lt $lines.Count; $lineIndex++) {
        $line = $lines[$lineIndex]
        if ([string]::IsNullOrWhiteSpace($line)) {
            continue
        }

        $parts = @()
        if ($headerInfo.mode -eq 'csv') {
            $parts = @($line -split ',', -1)
        } else {
            $parts = Split-TcpViewImportLine -Line $line -Mode $headerInfo.mode
        }

        if ($parts.Count -eq 0) {
            continue
        }

        while ($parts.Count -lt $headerInfo.columns.Count) {
            $parts += ""
        }

        $processName = (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Process', 'Process Name', 'Image')).Trim()
        if (-not (Test-NameMatches -Text $processName -Patterns $Patterns)) {
            continue
        }

        $localParsed = Split-EndpointHostPort -Text (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Local Address', 'Local Endpoint', 'Local'))
        $remoteParsed = Split-EndpointHostPort -Text (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Remote Address', 'Remote Endpoint', 'Remote'))
        $localPort = Try-ParseIntValue -Text (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Local Port'))
        $remotePort = Try-ParseIntValue -Text (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Remote Port'))

        if ($null -eq $localPort) {
            $localPort = $localParsed.port
        }
        if ($null -eq $remotePort) {
            $remotePort = $remoteParsed.port
        }

        $remoteValue = $remoteParsed.address
        $directCandidates = @()
        if ((Get-RemoteKind -Value $remoteValue) -eq 'domain') {
            $directCandidates = @($remoteValue)
        }

        $createTime = ConvertTo-IsoTimestamp -Text (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Create Time'))
        if ([string]::IsNullOrWhiteSpace($createTime)) {
            $createTime = $ImportedAt
        }

        [void]$rows.Add((New-RawRecord `
            -Timestamp $createTime `
            -Source 'tcpview_import' `
            -ProcessName $processName `
            -ProcessId (Get-IntOrZero -Value (Try-ParseIntValue -Text (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('PID', 'Process ID')))) `
            -ProcessPath "" `
            -Protocol (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Protocol')) `
            -State (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('State')) `
            -LocalAddress $localParsed.address `
            -LocalPort $localPort `
            -RemoteAddress $remoteValue `
            -RemotePort $remotePort `
            -DomainCandidates $directCandidates `
            -CreateTime $createTime `
            -ModuleName (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Module Name', 'Module')) `
            -SentPackets (Try-ParseIntValue -Text (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Sent Packets'))) `
            -RecvPackets (Try-ParseIntValue -Text (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Recv Packets', 'Received Packets'))) `
            -SentBytes (Try-ParseIntValue -Text (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Sent Bytes'))) `
            -RecvBytes (Try-ParseIntValue -Text (Get-ImportValue -Columns $parts -Map $headerMap -Aliases @('Recv Bytes', 'Received Bytes')))))
    }

    return @($rows.ToArray())
}

function Resolve-TcpvconRecords {
    param(
        [object[]]$ConsoleRecords,
        [object[]]$LiveRecords,
        [hashtable]$DnsByIp,
        [hashtable]$DnsByDomain
    )

    foreach ($record in @($ConsoleRecords)) {
        $candidates = @($LiveRecords | Where-Object {
            $_.protocol -eq $record.protocol -and
            $_.state -eq $record.state -and
            (
                ($record.pid -gt 0 -and $_.pid -eq $record.pid) -or
                $_.processName.Equals($record.processName, [System.StringComparison]::OrdinalIgnoreCase)
            )
        })

        $remoteMatches = @($candidates | Where-Object {
            Test-AddressMatch -Left $record.remoteAddress -Right $_.remoteAddress -DnsByIp $DnsByIp -DnsByDomain $DnsByDomain
        })
        if ($remoteMatches.Count -gt 0) {
            $candidates = $remoteMatches
        }

        $localMatches = @($candidates | Where-Object {
            Test-AddressMatch -Left $record.localAddress -Right $_.localAddress -DnsByIp $DnsByIp -DnsByDomain $DnsByDomain
        })
        if ($localMatches.Count -eq 1) {
            $candidates = $localMatches
        }

        if ($candidates.Count -ne 1) {
            continue
        }

        $liveMatch = $candidates[0]
        if ($null -eq $record.localPort -and $null -ne $liveMatch.localPort) {
            $record.localPort = $liveMatch.localPort
        }
        if ($null -eq $record.remotePort -and $null -ne $liveMatch.remotePort) {
            $record.remotePort = $liveMatch.remotePort
        }

        $consoleRemoteKind = Get-RemoteKind -Value $record.remoteAddress
        $liveRemoteKind = Get-RemoteKind -Value $liveMatch.remoteAddress
        if ($consoleRemoteKind -eq 'domain' -and $liveRemoteKind -eq 'ip') {
            $domainSet = @{}
            foreach ($candidate in @($record.domainCandidates)) {
                $domainSet[$candidate] = $true
            }
            $domainSet[$record.remoteAddress] = $true
            $record.domainCandidates = @($domainSet.Keys | Sort-Object)
            $record.remoteAddress = $liveMatch.remoteAddress
        } elseif ([string]::IsNullOrWhiteSpace($record.remoteAddress) -or $record.remoteAddress -eq '*') {
            $record.remoteAddress = $liveMatch.remoteAddress
        }

        if ([string]::IsNullOrWhiteSpace($record.localAddress) -or $record.localAddress -eq '*') {
            $record.localAddress = $liveMatch.localAddress
        }
    }

    return @($ConsoleRecords)
}

function Add-DnsCandidatesToRecords {
    param(
        [object[]]$Records,
        [hashtable]$DnsByIp
    )

    foreach ($record in @($Records)) {
        $candidateSet = @{}
        foreach ($candidate in @($record.domainCandidates)) {
            $normalized = Normalize-HostValue -Text $candidate
            if (Test-AllowedDomainCandidate -Value $normalized) {
                $candidateSet[$normalized] = $true
            }
        }

        if (Test-AllowedDomainCandidate -Value $record.remoteAddress) {
            $candidateSet[$record.remoteAddress] = $true
        }

        if (Test-ExternalIpCandidate -Value $record.remoteAddress) {
            foreach ($domain in @(Get-DnsNamesForIp -IpAddress $record.remoteAddress -DnsByIp $DnsByIp)) {
                if (Test-AllowedDomainCandidate -Value $domain) {
                    $candidateSet[$domain] = $true
                }
            }
        }

        $record.domainCandidates = @($candidateSet.Keys | Sort-Object)
        $record.confidence = if ($candidateSet.Count -gt 0) { 'high' } else { 'none' }
    }

    return @($Records)
}

function Get-MergeKey {
    param([object]$Record)

    return ("{0}|{1}|{2}|{3}|{4}" -f `
        $Record.protocol.ToLowerInvariant(), `
        ([string]$Record.remoteAddress).ToLowerInvariant(), `
        [string]$Record.remotePort, `
        $Record.state.ToLowerInvariant(), `
        $Record.processName.ToLowerInvariant())
}

function Merge-NormalizedEndpoints {
    param([object[]]$Records)

    $map = @{}
    foreach ($record in @($Records)) {
        $key = Get-MergeKey -Record $record
        if (-not $map.ContainsKey($key)) {
            $candidateSet = @{}
            foreach ($candidate in @($record.domainCandidates)) {
                $candidateSet[$candidate] = $true
            }

            $map[$key] = [PSCustomObject]@{
                sources = @($record.source)
                processName = $record.processName
                pid = $record.pid
                protocol = $record.protocol
                state = $record.state
                localAddress = $record.localAddress
                localPort = $record.localPort
                remoteAddress = $record.remoteAddress
                remotePort = $record.remotePort
                remoteKind = Get-RemoteKind -Value $record.remoteAddress
                domainCandidates = @($candidateSet.Keys | Sort-Object)
                confidence = $record.confidence
                firstSeen = $record.timestamp
                lastSeen = $record.timestamp
                observationCount = 1
                sentPackets = $record.sentPackets
                recvPackets = $record.recvPackets
                sentBytes = $record.sentBytes
                recvBytes = $record.recvBytes
            }
            continue
        }

        $endpoint = $map[$key]
        $sourceSet = @{}
        foreach ($source in @($endpoint.sources + $record.source)) {
            if (-not [string]::IsNullOrWhiteSpace([string]$source)) {
                $sourceSet[[string]$source] = $true
            }
        }
        $endpoint.sources = @($sourceSet.Keys | Sort-Object)

        if (($endpoint.pid -le 0) -and ($record.pid -gt 0)) {
            $endpoint.pid = $record.pid
        }
        if ([string]::IsNullOrWhiteSpace($endpoint.localAddress) -and -not [string]::IsNullOrWhiteSpace($record.localAddress)) {
            $endpoint.localAddress = $record.localAddress
        }
        if (($null -eq $endpoint.localPort) -and ($null -ne $record.localPort)) {
            $endpoint.localPort = $record.localPort
        }
        if (($null -eq $endpoint.remotePort) -and ($null -ne $record.remotePort)) {
            $endpoint.remotePort = $record.remotePort
        }
        if ([string]::Compare($record.timestamp, $endpoint.firstSeen, [System.StringComparison]::Ordinal) -lt 0) {
            $endpoint.firstSeen = $record.timestamp
        }
        if ([string]::Compare($record.timestamp, $endpoint.lastSeen, [System.StringComparison]::Ordinal) -gt 0) {
            $endpoint.lastSeen = $record.timestamp
        }

        $domainSet = @{}
        foreach ($candidate in @($endpoint.domainCandidates + $record.domainCandidates)) {
            $normalized = Normalize-HostValue -Text $candidate
            if ((Get-RemoteKind -Value $normalized) -eq 'domain') {
                $domainSet[$normalized] = $true
            }
        }
        $endpoint.domainCandidates = @($domainSet.Keys | Sort-Object)
        $endpoint.confidence = if ($endpoint.domainCandidates.Count -gt 0) { 'high' } else { 'none' }
        $endpoint.observationCount++

        foreach ($propertyName in @('sentPackets', 'recvPackets', 'sentBytes', 'recvBytes')) {
            $currentValue = $endpoint.$propertyName
            $newValue = $record.$propertyName
            if ($null -eq $currentValue -and $null -ne $newValue) {
                $endpoint.$propertyName = $newValue
            } elseif ($null -ne $currentValue -and $null -ne $newValue -and $newValue -gt $currentValue) {
                $endpoint.$propertyName = $newValue
            }
        }
    }

    return @($map.Values | Sort-Object processName, protocol, remoteAddress, remotePort, state)
}

function Convert-ArrayToJsonText {
    param(
        [object[]]$Items,
        [int]$Depth = 8
    )

    $array = @($Items)
    if ($array.Count -eq 0) {
        return "[]"
    }

    if ($array.Count -eq 1) {
        return "[`r`n$((ConvertTo-Json -InputObject $array[0] -Depth $Depth))`r`n]"
    }

    return ConvertTo-Json -InputObject $array -Depth $Depth
}

function Get-CsvHeaderLine {
    param([string[]]$Headers)

    return '"' + ($Headers -join '","') + '"'
}

function Write-CsvFile {
    param(
        [string]$Path,
        [object[]]$Rows,
        [string[]]$Headers
    )

    $items = @($Rows)
    if ($items.Count -gt 0) {
        $items | Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8
    } else {
        Set-Content -LiteralPath $Path -Value (Get-CsvHeaderLine -Headers $Headers) -Encoding UTF8
    }
}

function Get-TopLines {
    param(
        [hashtable]$Counts,
        [int]$Limit = 10
    )

    return @(
        $Counts.GetEnumerator() |
            Sort-Object @{ Expression = { $_.Value }; Descending = $true }, @{ Expression = { $_.Key }; Descending = $false } |
            Select-Object -First $Limit |
            ForEach-Object { "{0}`t{1}" -f $_.Key, $_.Value }
    )
}

function Move-DuplicateOutputsToArchive {
    param(
        [string]$Root,
        [string]$ArchiveRoot,
        [string]$TraceSlug
    )

    $tracePrefix = "apptrace-$TraceSlug"
    $rootFiles = New-Object System.Collections.Generic.List[object]
    foreach ($pattern in @("$tracePrefix-*.txt", "$tracePrefix-*.csv", "$tracePrefix-*.json", "$tracePrefix-*.log")) {
        foreach ($file in @(Get-ChildItem -Path $Root -Filter $pattern -File -ErrorAction SilentlyContinue)) {
            [void]$rootFiles.Add($file)
        }
    }

    $nestedRoot = Join-Path $Root 'BlitzFix'
    $nestedItems = @()
    if (Test-Path -LiteralPath $nestedRoot) {
        $nestedItems = @(Get-ChildItem -LiteralPath $nestedRoot -Force)
    }

    if ($rootFiles.Count -eq 0 -and $nestedItems.Count -eq 0) {
        return [PSCustomObject]@{
            archiveDir = ""
            moved = @()
        }
    }

    $archiveDir = Join-Path $ArchiveRoot (Get-Stamp)
    Ensure-Directory -Path $archiveDir
    $moved = New-Object System.Collections.Generic.List[object]

    foreach ($file in @($rootFiles | Sort-Object FullName -Unique)) {
        $destination = Join-Path $archiveDir $file.Name
        Move-Item -LiteralPath $file.FullName -Destination $destination
        [void]$moved.Add([PSCustomObject]@{
            from = $file.FullName
            to = $destination
        })
    }

    if ($nestedItems.Count -gt 0) {
        $nestedArchiveRoot = Join-Path $archiveDir 'BlitzFix'
        Ensure-Directory -Path $nestedArchiveRoot
        foreach ($item in $nestedItems) {
            $destination = Join-Path $nestedArchiveRoot $item.Name
            Move-Item -LiteralPath $item.FullName -Destination $destination
            [void]$moved.Add([PSCustomObject]@{
                from = $item.FullName
                to = $destination
            })
        }

        if (@(Get-ChildItem -LiteralPath $nestedRoot -Force).Count -eq 0) {
            Remove-Item -LiteralPath $nestedRoot -Force
        }
    }

    return [PSCustomObject]@{
        archiveDir = $archiveDir
        moved = @($moved.ToArray())
    }
}

if ($DurationSeconds -lt 0) {
    throw "DurationSeconds must be >= 0."
}
if ($IntervalSeconds -lt 1) {
    throw "IntervalSeconds must be >= 1."
}
$ProcessPatterns = @(
    foreach ($pattern in @($ProcessPatterns)) {
        foreach ($part in (([string]$pattern) -split ';')) {
            $value = $part.Trim()
            if (-not [string]::IsNullOrWhiteSpace($value)) {
                $value
            }
        }
    }
)
if (-not $ProcessPatterns -or @($ProcessPatterns).Count -eq 0) {
    throw "ProcessPatterns must contain at least one pattern."
}

$traceSlugSafe = ([string]$TraceSlug).Trim().ToLowerInvariant() -replace '[^a-z0-9]+', '-'
$traceSlugSafe = $traceSlugSafe.Trim('-')
if ([string]::IsNullOrWhiteSpace($traceSlugSafe)) {
    throw "TraceSlug must contain at least one letter or number."
}

$appDisplayNameSafe = ([string]$AppDisplayName).Trim()
if ([string]::IsNullOrWhiteSpace($appDisplayNameSafe)) {
    $appDisplayNameSafe = $traceSlugSafe
}

$tracePrefix = "apptrace-$traceSlugSafe"
$blitzFixRoot = Get-BlitzFixRoot
$inputRoot = Join-Path $blitzFixRoot 'input'
$archiveRoot = Join-Path $blitzFixRoot 'archive'
$outputRoot = Resolve-CanonicalPath -Root $blitzFixRoot -Candidate $OutputDir -DefaultChild 'output'
$tcpViewImportPath = Resolve-CanonicalPath -Root $blitzFixRoot -Candidate $TcpViewImportPath -DefaultChild (Join-Path 'input' ("tcpview-$traceSlugSafe-raw.txt"))
$tcpvconPath = Join-Path $blitzFixRoot 'TCPView\tcpvcon.exe'

Ensure-Directory -Path $inputRoot
Ensure-Directory -Path $archiveRoot
Ensure-Directory -Path $outputRoot

$archiveResult = Move-DuplicateOutputsToArchive -Root $blitzFixRoot -ArchiveRoot $archiveRoot -TraceSlug $traceSlugSafe
$warnings = New-Object System.Collections.Generic.List[string]

if ($archiveResult.moved.Count -gt 0) {
    Write-Info ("Archived duplicate $appDisplayNameSafe outputs to {0}" -f (Get-RelativeBlitzFixPath -Path $archiveResult.archiveDir -Root $blitzFixRoot))
}

$useTcpvcon = $false
$tcpvconFlags = @()
$tcpvconSourceStatus = "not found"

if (-not [string]::IsNullOrWhiteSpace($tcpvconPath) -and (Test-Path -LiteralPath $tcpvconPath)) {
    $tcpvconSourceStatus = "found"
    # Run a test of tcpvcon with -nobanner to check support and accept EULA.
    $testProc = New-Object System.Diagnostics.Process
    $testProc.StartInfo.FileName = $tcpvconPath
    $testProc.StartInfo.Arguments = "-accepteula -nobanner"
    $testProc.StartInfo.UseShellExecute = $false
    $testProc.StartInfo.RedirectStandardOutput = $true
    $testProc.StartInfo.RedirectStandardError = $true
    $testProc.StartInfo.CreateNoWindow = $true

    $started = $false
    try {
        $started = $testProc.Start()
    } catch {
        Write-WarnLine -Message "Warning: Failed to start tcpvcon EULA check: $($_.Exception.Message)" -Warnings $warnings
    }

    if ($started) {
        if ($testProc.WaitForExit(3000)) {
            $stdout = $testProc.StandardOutput.ReadToEnd()
            $stderr = $testProc.StandardError.ReadToEnd()
            $exitCode = $testProc.ExitCode

            $unsupported = $false
            if ($stdout -match "unknown option" -or $stderr -match "unknown option" -or $stdout -match "Usage:" -or $exitCode -ne 0) {
                if ($stdout -match "nobanner" -or $stderr -match "nobanner") {
                    $unsupported = $true
                }
            }

            if (-not $unsupported) {
                $useTcpvcon = $true
                $tcpvconFlags = @("-accepteula", "-a", "-c", "-nobanner")
                $tcpvconSourceStatus = "enabled"
            } else {
                # Try running without -nobanner
                $testProc2 = New-Object System.Diagnostics.Process
                $testProc2.StartInfo.FileName = $tcpvconPath
                $testProc2.StartInfo.Arguments = "-accepteula"
                $testProc2.StartInfo.UseShellExecute = $false
                $testProc2.StartInfo.RedirectStandardOutput = $true
                $testProc2.StartInfo.RedirectStandardError = $true
                $testProc2.StartInfo.CreateNoWindow = $true

                $started2 = $false
                try {
                    $started2 = $testProc2.Start()
                } catch {}

                if ($started2 -and $testProc2.WaitForExit(3000)) {
                    $useTcpvcon = $true
                    $tcpvconFlags = @("-accepteula", "-a", "-c")
                    $tcpvconSourceStatus = "enabled"
                } else {
                    try { $testProc2.Kill() } catch {}
                    Write-WarnLine -Message "Warning: tcpvcon check failed or timed out. EULA might not be accepted. Continuing PowerShell-only." -Warnings $warnings
                }
            }
        } else {
            try { $testProc.Kill() } catch {}
            Write-WarnLine -Message "Warning: tcpvcon EULA check timed out after 3 seconds. Continuing PowerShell-only." -Warnings $warnings
        }
    }
}

if (-not $useTcpvcon) {
    $tcpvconPath = ""
}

# Initialize live log
$liveLog = Join-Path $outputRoot "$tracePrefix-live.log"
try {
    $null = New-Item -Path $liveLog -ItemType File -Force -ErrorAction SilentlyContinue
    $script:liveLogPath = $liveLog
} catch {
    Write-WarnLine -Message "Warning: Failed to create live log file at $($liveLog): $($_.Exception.Message)" -Warnings $warnings
}

# Print startup diagnostics
$importStatus = if (Test-Path -LiteralPath $tcpViewImportPath) { "found" } else { "not found" }
Write-LiveMessage -Message "PowerShell source: enabled" -ForegroundColor Gray
Write-LiveMessage -Message "tcpvcon source: $tcpvconSourceStatus" -ForegroundColor Gray
Write-LiveMessage -Message "TCPView import: $importStatus" -ForegroundColor Gray
Write-LiveMessage -Message "OutputDir: $outputRoot" -ForegroundColor Gray
Write-LiveMessage -Message "InputPath: $tcpViewImportPath" -ForegroundColor Gray

$outputPaths = [PSCustomObject]@{
    domains = Join-Path $outputRoot "$tracePrefix-domains.txt"
    ips = Join-Path $outputRoot "$tracePrefix-ips.txt"
    ports = Join-Path $outputRoot "$tracePrefix-ports.txt"
    synSent = Join-Path $outputRoot "$tracePrefix-syn-sent.txt"
    established = Join-Path $outputRoot "$tracePrefix-established.txt"
    endpointsCsv = Join-Path $outputRoot "$tracePrefix-endpoints.csv"
    endpointsJson = Join-Path $outputRoot "$tracePrefix-endpoints.json"
    summary = Join-Path $outputRoot "$tracePrefix-summary.txt"
}

$externalListState = [PSCustomObject]@{
    Enabled = $false
    IpPath = ""
    DomainPath = ""
    Ips = @{}
    Domains = @{}
}

if (-not $DisableExternalListSync -and -not [string]::IsNullOrWhiteSpace($ExternalListsDir)) {
    if (Test-Path -LiteralPath $ExternalListsDir) {
        $externalListState.IpPath = Join-Path $ExternalListsDir 'ipset-all.txt'
        $externalListState.DomainPath = Join-Path $ExternalListsDir 'list-ultimate.txt'
        if (-not (Test-Path -LiteralPath $externalListState.IpPath)) {
            [void](New-Item -ItemType File -Path $externalListState.IpPath -Force)
        }
        if (-not (Test-Path -LiteralPath $externalListState.DomainPath)) {
            [void](New-Item -ItemType File -Path $externalListState.DomainPath -Force)
        }

        $externalListState.Ips = New-LineSetFromFile -Path $externalListState.IpPath
        $externalListState.Domains = New-LineSetFromFile -Path $externalListState.DomainPath
        $externalListState.Enabled = $true
        Write-LiveMessage -Message ("External list sync: enabled -> {0}" -f $ExternalListsDir) -ForegroundColor Gray
    } else {
        Write-WarnLine -Message ("External list sync skipped; directory not found: {0}" -f $ExternalListsDir) -Warnings $warnings
    }
} elseif ($DisableExternalListSync) {
    Write-LiveMessage -Message "External list sync: disabled" -ForegroundColor Gray
} else {
    Write-LiveMessage -Message "External list sync: not configured" -ForegroundColor Gray
}

$rawRecords = New-Object System.Collections.Generic.List[object]
$dnsRecords = New-Object System.Collections.Generic.List[object]
$observedProcessSet = @{}
$startTime = Get-Date
$endTime = $startTime.AddSeconds($DurationSeconds)

# Initialize trackers for live unique discoveries
$seenIPs = @{}
$seenDomains = @{}
$seenPorts = @{}
$seenSynSents = @{}
$liveDomainMessagesShown = 0
$maxLiveDomainMessages = 12
$liveDomainSuppressionShown = $false
$lastProcessSeenTime = Get-Date
$noProcessGuidancePrinted = $false

if ($DurationSeconds -eq 0) {
    Write-Info ("Tracing {0} infinitely (press Ctrl+C to stop)..." -f $appDisplayNameSafe)
} else {
    Write-Info ("Tracing {0} for {1}s..." -f $appDisplayNameSafe, $DurationSeconds)
}

while ($DurationSeconds -eq 0 -or (Get-Date) -lt $endTime) {
    $timestamp = (Get-Date).ToString("o")
    $processSnapshot = Get-ProcessSnapshot -Patterns $ProcessPatterns -Warnings $warnings
    foreach ($process in @($processSnapshot.processes)) {
        $observedProcessSet[("{0}|{1}|{2}" -f $process.processName, $process.pid, $process.processPath)] = $true
    }

    # Update traced process presence status
    if ($processSnapshot.processes.Count -gt 0) {
        $lastProcessSeenTime = Get-Date
        $noProcessGuidancePrinted = $false
    }

    $dnsSnapshot = Get-DnsCacheSnapshot -Timestamp $timestamp -Warnings $warnings
    foreach ($dnsRecord in @($dnsSnapshot)) {
        [void]$dnsRecords.Add($dnsRecord)
    }
    $dnsIndexForCycle = New-DnsIndex -Records $dnsSnapshot

    $liveRecords = @(Get-LiveConnectionRecords -Timestamp $timestamp -ProcessByPid $processSnapshot.byPid -Warnings $warnings)
    $consoleRecords = @()
    $tcpvconCycleStatus = "skipped"

    if (-not [string]::IsNullOrWhiteSpace($tcpvconPath) -and $processSnapshot.processes.Count -gt 0) {
        $tcpvconResult = Get-TcpvconSnapshotRecords `
            -Timestamp $timestamp `
            -TcpvconPath $tcpvconPath `
            -Processes $processSnapshot.processes `
            -Patterns $ProcessPatterns `
            -TcpvconFlags $tcpvconFlags `
            -Warnings $warnings
        
        $consoleRecords = $tcpvconResult.records
        $tcpvconCycleStatus = $tcpvconResult.status

        if ($consoleRecords.Count -gt 0) {
            $consoleRecords = @(Resolve-TcpvconRecords -ConsoleRecords $consoleRecords -LiveRecords $liveRecords -DnsByIp $dnsIndexForCycle.byIp -DnsByDomain $dnsIndexForCycle.byDomain)
        }
    }

    foreach ($record in @($liveRecords + $consoleRecords)) {
        [void]$rawRecords.Add($record)
    }

    # Check for live unique discoveries in this cycle
    $cycleRecords = @($liveRecords + $consoleRecords)
    $cycleRecordsResolved = @(Add-DnsCandidatesToRecords -Records $cycleRecords -DnsByIp $dnsIndexForCycle.byIp)

    $cycleNewIPs = 0
    $cycleNewDomains = 0
    $cycleNewPorts = 0

    foreach ($record in $cycleRecordsResolved) {
        if (-not (Test-ExternalEndpointRecord -Record $record)) {
            continue
        }

        # 1. IP address check
        $remoteAddress = $record.remoteAddress
        $remoteKind = Get-RemoteKind -Value $remoteAddress
        if ($remoteKind -eq 'ip') {
            if (-not $seenIPs.ContainsKey($remoteAddress)) {
                $seenIPs[$remoteAddress] = $true
                $cycleNewIPs++
                Write-LiveMessage -Message "NEW IP: $remoteAddress" -ForegroundColor Green
            }
        }

        # 2. Port check
        if ($null -ne $record.remotePort -and $record.remotePort -gt 0) {
            $portStr = [string]$record.remotePort
            if (-not $seenPorts.ContainsKey($portStr)) {
                $seenPorts[$portStr] = $true
                $cycleNewPorts++
                Write-LiveMessage -Message "NEW PORT: $portStr" -ForegroundColor Green
            }
        }

        # 3. Domain check
        $domainsToCheck = New-Object System.Collections.Generic.List[string]
        if ($remoteKind -eq 'domain') {
            [void]$domainsToCheck.Add($remoteAddress)
        }
        foreach ($cand in @($record.domainCandidates)) {
            [void]$domainsToCheck.Add($cand)
        }

        $uniqueDomainsToCheck = @($domainsToCheck | Sort-Object -Unique)
        foreach ($domain in $uniqueDomainsToCheck) {
            if (-not $seenDomains.ContainsKey($domain)) {
                $seenDomains[$domain] = $true
                $cycleNewDomains++
                if ($liveDomainMessagesShown -lt $maxLiveDomainMessages) {
                    Write-LiveMessage -Message "NEW DOMAIN: $domain" -ForegroundColor Green
                    $liveDomainMessagesShown++
                } elseif (-not $liveDomainSuppressionShown) {
                    Write-LiveMessage -Message "Further domain lines are hidden; full filtered results will be written to the project lists." -ForegroundColor DarkGray
                    $liveDomainSuppressionShown = $true
                }
            }
        }

        # 4. Syn Sent check
        if ($record.state -eq 'Syn Sent') {
            $portVal = $record.remotePort
            if ($null -ne $portVal) {
                $synSentEndpoints = New-Object System.Collections.Generic.List[string]
                if ($uniqueDomainsToCheck.Count -gt 0) {
                    foreach ($domain in $uniqueDomainsToCheck) {
                        [void]$synSentEndpoints.Add(("{0}:{1}" -f $domain, $portVal))
                    }
                } else {
                    [void]$synSentEndpoints.Add(("{0}:{1}" -f $remoteAddress, $portVal))
                }

                foreach ($synSentEp in $synSentEndpoints) {
                    if (-not $seenSynSents.ContainsKey($synSentEp)) {
                        $seenSynSents[$synSentEp] = $true
                        Write-LiveMessage -Message "NEW SYN_SENT: $synSentEp" -ForegroundColor Green
                    }
                }
            }
        }
    }

    # No process guidance warning
    if ($processSnapshot.processes.Count -eq 0) {
        $noProcessElapsed = ((Get-Date) - $lastProcessSeenTime).TotalSeconds
        if ($noProcessElapsed -gt 10 -and -not $noProcessGuidancePrinted) {
            Write-LiveMessage -Message "$appDisplayNameSafe process not found yet. Launch $appDisplayNameSafe and reproduce the issue." -ForegroundColor Yellow
            $noProcessGuidancePrinted = $true
        }
    }

    # Print heartbeat
    $elapsedSec = [int]((Get-Date) - $startTime).TotalSeconds
    if ($DurationSeconds -gt 0 -and $elapsedSec -gt $DurationSeconds) {
        $elapsedSec = $DurationSeconds
    }
    $elapsedStr = "{0:d3}" -f $elapsedSec

    $durationStr = if ($DurationSeconds -eq 0) { "inf" } else { "$($DurationSeconds)s" }

    if ($processSnapshot.processes.Count -eq 0) {
        Write-LiveMessage -Message "[t+$($elapsedStr)s/$($durationStr)] waiting for $appDisplayNameSafe process... tcpvcon=skipped" -ForegroundColor Yellow
    } else {
        $totalEndpoints = $cycleRecords.Count
        Write-LiveMessage -Message "[t+$($elapsedStr)s/$($durationStr)] processes=$($processSnapshot.processes.Count) endpoints=$totalEndpoints newIPs=$cycleNewIPs newDomains=$cycleNewDomains newPorts=$cycleNewPorts tcpvcon=$tcpvconCycleStatus" -ForegroundColor Cyan
    }

    # Write output files in real-time
    try {
        $dnsIndexCycle = New-DnsIndex -Records @($dnsRecords.ToArray())
        $allRawRecordsCycle = @(Add-DnsCandidatesToRecords -Records @($rawRecords.ToArray()) -DnsByIp $dnsIndexCycle.byIp)
        $endpointsCycle = @(Merge-NormalizedEndpoints -Records $allRawRecordsCycle)

        $ipSetCycle = @{}
        $domainSetCycle = @{}
        $portSetCycle = @{}
        $portCountsCycle = @{}
        $domainCountsCycle = @{}
        $ipCountsCycle = @{}
        $synSentCountsCycle = @{}

        foreach ($endpoint in @($endpointsCycle)) {
            if (-not (Test-ExternalEndpointRecord -Record $endpoint)) {
                continue
            }

            if ((Get-RemoteKind -Value $endpoint.remoteAddress) -eq 'ip') {
                Add-SetValue -Set $ipSetCycle -Value $endpoint.remoteAddress
                Add-CountValue -Counts $ipCountsCycle -Key $endpoint.remoteAddress -Amount $endpoint.observationCount
            }

            if ($null -ne $endpoint.remotePort) {
                Add-SetValue -Set $portSetCycle -Value ([string]$endpoint.remotePort)
                Add-CountValue -Counts $portCountsCycle -Key ([string]$endpoint.remotePort) -Amount $endpoint.observationCount
            }

            foreach ($domain in @($endpoint.domainCandidates)) {
                Add-SetValue -Set $domainSetCycle -Value $domain
                Add-CountValue -Counts $domainCountsCycle -Key $domain -Amount $endpoint.observationCount
            }

            if ($endpoint.state -eq 'Syn Sent') {
                $synKey = "{0}`t{1}`t{2}:{3}" -f $endpoint.processName, $endpoint.protocol, $endpoint.remoteAddress, $endpoint.remotePort
                Add-CountValue -Counts $synSentCountsCycle -Key $synKey -Amount $endpoint.observationCount
            }
        }

        $endpointCsvRowsCycle = @($endpointsCycle | ForEach-Object {
            [PSCustomObject]@{
                sources = (@($_.sources) -join '; ')
                processName = $_.processName
                pid = $_.pid
                protocol = $_.protocol
                state = $_.state
                localAddress = $_.localAddress
                localPort = $_.localPort
                remoteAddress = $_.remoteAddress
                remotePort = $_.remotePort
                remoteKind = $_.remoteKind
                domainCandidates = (@($_.domainCandidates) -join '; ')
                confidence = $_.confidence
                firstSeen = $_.firstSeen
                lastSeen = $_.lastSeen
                observationCount = $_.observationCount
                sentPackets = $_.sentPackets
                recvPackets = $_.recvPackets
                sentBytes = $_.sentBytes
                recvBytes = $_.recvBytes
            }
        })

        Set-Content -LiteralPath $outputPaths.domains -Value @($domainSetCycle.Keys | Sort-Object) -Encoding UTF8 -ErrorAction SilentlyContinue
        Set-Content -LiteralPath $outputPaths.ips -Value @($ipSetCycle.Keys | Sort-Object) -Encoding UTF8 -ErrorAction SilentlyContinue
        Set-Content -LiteralPath $outputPaths.ports -Value @($portSetCycle.Keys | Sort-Object {[int]$_}) -Encoding UTF8 -ErrorAction SilentlyContinue
        Set-Content -LiteralPath $outputPaths.synSent -Value @($endpointsCycle | Where-Object { $_.state -eq 'Syn Sent' } | ForEach-Object { ConvertTo-Json -InputObject $_ -Depth 6 -Compress }) -Encoding UTF8 -ErrorAction SilentlyContinue
        Set-Content -LiteralPath $outputPaths.established -Value @($endpointsCycle | Where-Object { $_.state -eq 'Established' } | ForEach-Object { ConvertTo-Json -InputObject $_ -Depth 6 -Compress }) -Encoding UTF8 -ErrorAction SilentlyContinue
        Set-Content -LiteralPath $outputPaths.endpointsJson -Value (Convert-ArrayToJsonText -Items $endpointsCycle -Depth 8) -Encoding UTF8 -ErrorAction SilentlyContinue
        Write-CsvFile -Path $outputPaths.endpointsCsv -Rows $endpointCsvRowsCycle -Headers @('sources', 'processName', 'pid', 'protocol', 'state', 'localAddress', 'localPort', 'remoteAddress', 'remotePort', 'remoteKind', 'domainCandidates', 'confidence', 'firstSeen', 'lastSeen', 'observationCount', 'sentPackets', 'recvPackets', 'sentBytes', 'recvBytes')
        $externalCandidatesCycle = New-ExternalCandidateSets -Endpoints $endpointsCycle
        $externalSyncCycle = Sync-ExternalLists -State $externalListState -IpSet $externalCandidatesCycle.Ips -DomainSet $externalCandidatesCycle.Domains
        if ($externalSyncCycle.ips -gt 0 -or $externalSyncCycle.domains -gt 0) {
            Write-LiveMessage -Message ("External lists: +{0} IPs, +{1} domains" -f $externalSyncCycle.ips, $externalSyncCycle.domains) -ForegroundColor Green
        }

        $rawLiveCountCycle = @($allRawRecordsCycle | Where-Object { $_.source -eq 'live_trace' }).Count
        $rawConsoleCountCycle = @($allRawRecordsCycle | Where-Object { $_.source -eq 'tcpview_console' }).Count
        $rawImportCountCycle = 0
        $establishedCountCycle = @($endpointsCycle | Where-Object { $_.state -eq 'Established' }).Count
        $synSentCountCycle = @($endpointsCycle | Where-Object { $_.state -eq 'Syn Sent' }).Count
        $warningLinesCycle = if ($warnings.Count -gt 0) { @($warnings.ToArray()) } else { @('none') }

        $summaryLinesCycle = @(
            "total normalized endpoints: $($allRawRecordsCycle.Count)"
            "total raw live_trace records: $rawLiveCountCycle"
            "total raw tcpview_console records: $rawConsoleCountCycle"
            "total raw tcpview_import records: $rawImportCountCycle"
            "deduplicated endpoint count: $($endpointsCycle.Count)"
            "established count: $establishedCountCycle"
            "syn-sent count: $synSentCountCycle"
            "unique IP count: $($ipSetCycle.Count)"
            "unique domain count: $($domainSetCycle.Count)"
            "unique port count: $($portSetCycle.Count)"
            "external appended IP count: $($externalSyncCycle.ips)"
            "external appended domain count: $($externalSyncCycle.domains)"
            "observed process count: $($observedProcessSet.Count)"
            "top ports:"
        ) + (Get-TopLines -Counts $portCountsCycle) + @(
            "top domains:"
        ) + (Get-TopLines -Counts $domainCountsCycle) + @(
            "top IPs:"
        ) + (Get-TopLines -Counts $ipCountsCycle) + @(
            "top Syn Sent endpoints:"
        ) + (Get-TopLines -Counts $synSentCountsCycle) + @(
            "warnings:"
        ) + $warningLinesCycle + @(
            "output file paths:"
            "  domains: $(Get-RelativeBlitzFixPath -Path $outputPaths.domains -Root $blitzFixRoot)"
            "  ips: $(Get-RelativeBlitzFixPath -Path $outputPaths.ips -Root $blitzFixRoot)"
            "  ports: $(Get-RelativeBlitzFixPath -Path $outputPaths.ports -Root $blitzFixRoot)"
            "  syn-sent: $(Get-RelativeBlitzFixPath -Path $outputPaths.synSent -Root $blitzFixRoot)"
            "  established: $(Get-RelativeBlitzFixPath -Path $outputPaths.established -Root $blitzFixRoot)"
            "  endpoints csv: $(Get-RelativeBlitzFixPath -Path $outputPaths.endpointsCsv -Root $blitzFixRoot)"
            "  endpoints json: $(Get-RelativeBlitzFixPath -Path $outputPaths.endpointsJson -Root $blitzFixRoot)"
            "  summary: $(Get-RelativeBlitzFixPath -Path $outputPaths.summary -Root $blitzFixRoot)"
        )
        Set-Content -LiteralPath $outputPaths.summary -Value $summaryLinesCycle -Encoding UTF8 -ErrorAction SilentlyContinue
    } catch {
        # Fail silently during loop
    }

    Start-Sleep -Seconds $IntervalSeconds
}

$importTimestamp = (Get-Date).ToString("o")
$importRecords = @(Import-TcpViewFallbackRecords -Path $tcpViewImportPath -Patterns $ProcessPatterns -ImportedAt $importTimestamp -Warnings $warnings)
foreach ($record in @($importRecords)) {
    [void]$rawRecords.Add($record)
}

$dnsIndex = New-DnsIndex -Records @($dnsRecords.ToArray())
$allRawRecords = @(Add-DnsCandidatesToRecords -Records @($rawRecords.ToArray()) -DnsByIp $dnsIndex.byIp)
$endpoints = @(Merge-NormalizedEndpoints -Records $allRawRecords)

$ipSet = @{}
$domainSet = @{}
$portSet = @{}
$portCounts = @{}
$domainCounts = @{}
$ipCounts = @{}
$synSentCounts = @{}

foreach ($endpoint in @($endpoints)) {
    if (-not (Test-ExternalEndpointRecord -Record $endpoint)) {
        continue
    }

    if ((Get-RemoteKind -Value $endpoint.remoteAddress) -eq 'ip') {
        Add-SetValue -Set $ipSet -Value $endpoint.remoteAddress
        Add-CountValue -Counts $ipCounts -Key $endpoint.remoteAddress -Amount $endpoint.observationCount
    }

    if ($null -ne $endpoint.remotePort) {
        Add-SetValue -Set $portSet -Value ([string]$endpoint.remotePort)
        Add-CountValue -Counts $portCounts -Key ([string]$endpoint.remotePort) -Amount $endpoint.observationCount
    }

    foreach ($domain in @($endpoint.domainCandidates)) {
        Add-SetValue -Set $domainSet -Value $domain
        Add-CountValue -Counts $domainCounts -Key $domain -Amount $endpoint.observationCount
    }

    if ($endpoint.state -eq 'Syn Sent') {
        $synKey = "{0}`t{1}`t{2}:{3}" -f $endpoint.processName, $endpoint.protocol, $endpoint.remoteAddress, $endpoint.remotePort
        Add-CountValue -Counts $synSentCounts -Key $synKey -Amount $endpoint.observationCount
    }
}

$endpointCsvRows = @($endpoints | ForEach-Object {
    [PSCustomObject]@{
        sources = (@($_.sources) -join '; ')
        processName = $_.processName
        pid = $_.pid
        protocol = $_.protocol
        state = $_.state
        localAddress = $_.localAddress
        localPort = $_.localPort
        remoteAddress = $_.remoteAddress
        remotePort = $_.remotePort
        remoteKind = $_.remoteKind
        domainCandidates = (@($_.domainCandidates) -join '; ')
        confidence = $_.confidence
        firstSeen = $_.firstSeen
        lastSeen = $_.lastSeen
        observationCount = $_.observationCount
        sentPackets = $_.sentPackets
        recvPackets = $_.recvPackets
        sentBytes = $_.sentBytes
        recvBytes = $_.recvBytes
    }
})

Set-Content -LiteralPath $outputPaths.domains -Value @($domainSet.Keys | Sort-Object) -Encoding UTF8
Set-Content -LiteralPath $outputPaths.ips -Value @($ipSet.Keys | Sort-Object) -Encoding UTF8
Set-Content -LiteralPath $outputPaths.ports -Value @($portSet.Keys | Sort-Object {[int]$_}) -Encoding UTF8
Set-Content -LiteralPath $outputPaths.synSent -Value @($endpoints | Where-Object { $_.state -eq 'Syn Sent' } | ForEach-Object { ConvertTo-Json -InputObject $_ -Depth 6 -Compress }) -Encoding UTF8
Set-Content -LiteralPath $outputPaths.established -Value @($endpoints | Where-Object { $_.state -eq 'Established' } | ForEach-Object { ConvertTo-Json -InputObject $_ -Depth 6 -Compress }) -Encoding UTF8
Set-Content -LiteralPath $outputPaths.endpointsJson -Value (Convert-ArrayToJsonText -Items $endpoints -Depth 8) -Encoding UTF8
Write-CsvFile -Path $outputPaths.endpointsCsv -Rows $endpointCsvRows -Headers @('sources', 'processName', 'pid', 'protocol', 'state', 'localAddress', 'localPort', 'remoteAddress', 'remotePort', 'remoteKind', 'domainCandidates', 'confidence', 'firstSeen', 'lastSeen', 'observationCount', 'sentPackets', 'recvPackets', 'sentBytes', 'recvBytes')
$externalCandidates = New-ExternalCandidateSets -Endpoints $endpoints
$externalSync = Sync-ExternalLists -State $externalListState -IpSet $externalCandidates.Ips -DomainSet $externalCandidates.Domains

$rawLiveCount = @($allRawRecords | Where-Object { $_.source -eq 'live_trace' }).Count
$rawConsoleCount = @($allRawRecords | Where-Object { $_.source -eq 'tcpview_console' }).Count
$rawImportCount = @($allRawRecords | Where-Object { $_.source -eq 'tcpview_import' }).Count
$establishedCount = @($endpoints | Where-Object { $_.state -eq 'Established' }).Count
$synSentCount = @($endpoints | Where-Object { $_.state -eq 'Syn Sent' }).Count
$warningLines = if ($warnings.Count -gt 0) { @($warnings.ToArray()) } else { @('none') }

$summaryLines = @(
    "total normalized endpoints: $($allRawRecords.Count)"
    "total raw live_trace records: $rawLiveCount"
    "total raw tcpview_console records: $rawConsoleCount"
    "total raw tcpview_import records: $rawImportCount"
    "deduplicated endpoint count: $($endpoints.Count)"
    "established count: $establishedCount"
    "syn-sent count: $synSentCount"
    "unique IP count: $($ipSet.Count)"
    "unique domain count: $($domainSet.Count)"
    "unique port count: $($portSet.Count)"
    "external appended IP count: $($externalSync.ips)"
    "external appended domain count: $($externalSync.domains)"
    "observed process count: $($observedProcessSet.Count)"
    "top ports:"
) + (Get-TopLines -Counts $portCounts) + @(
    "top domains:"
) + (Get-TopLines -Counts $domainCounts) + @(
    "top IPs:"
) + (Get-TopLines -Counts $ipCounts) + @(
    "top Syn Sent endpoints:"
) + (Get-TopLines -Counts $synSentCounts) + @(
    "warnings:"
) + $warningLines + @(
    "output file paths:"
    "  domains: $(Get-RelativeBlitzFixPath -Path $outputPaths.domains -Root $blitzFixRoot)"
    "  ips: $(Get-RelativeBlitzFixPath -Path $outputPaths.ips -Root $blitzFixRoot)"
    "  ports: $(Get-RelativeBlitzFixPath -Path $outputPaths.ports -Root $blitzFixRoot)"
    "  syn-sent: $(Get-RelativeBlitzFixPath -Path $outputPaths.synSent -Root $blitzFixRoot)"
    "  established: $(Get-RelativeBlitzFixPath -Path $outputPaths.established -Root $blitzFixRoot)"
    "  endpoints csv: $(Get-RelativeBlitzFixPath -Path $outputPaths.endpointsCsv -Root $blitzFixRoot)"
    "  endpoints json: $(Get-RelativeBlitzFixPath -Path $outputPaths.endpointsJson -Root $blitzFixRoot)"
    "  summary: $(Get-RelativeBlitzFixPath -Path $outputPaths.summary -Root $blitzFixRoot)"
)
Set-Content -LiteralPath $outputPaths.summary -Value $summaryLines -Encoding UTF8

Write-Host ""
Write-Host "Done."
Write-Host ("Endpoints CSV: {0}" -f (Get-RelativeBlitzFixPath -Path $outputPaths.endpointsCsv -Root $blitzFixRoot))
Write-Host ("Summary: {0}" -f (Get-RelativeBlitzFixPath -Path $outputPaths.summary -Root $blitzFixRoot))
